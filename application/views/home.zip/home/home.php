<!doctype html>
<html lang="en">
<head>
    <title>Planet Web IT Service</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>pwit/style2.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>


</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light pt-3 text-dark">
    <div class="container">       
            <a class="navbar-brand" href=""><img class="img-fluid" src="<?php echo base_url();?>pwit/img/logo2.png"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto font-weight-bold">
                    <li class="nav-item">
                        <a class="nav-link" href="#Whatwedo">HOME</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="#aboutus">ABOUT US</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="#features">SERVICES</a>
                    </li>  
                    <li class="nav-item">
                        <a class="nav-link" href="#work">PORTFOLIO</a>
                    </li>                                     

                    <li class="nav-item">
                        <a class="nav-link" href="#testimonial">TEAM</a>  
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#testimonial">CONTACT US</a>  
                    </li>
                     <button type="button text text-left" class="btn text-white">REQUEST QUOTE</button>
                </ul>
            </div>              
    </div>    
</nav>


<section class="banner">
    <div class="container-fluid">
        <div class="row">
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                      <img src="<?php echo base_url();?>pwit/img/crism.jpg" class="d-block w-100 img-fluid" alt="...">
                    <!--  <div class="carousel-caption d-none d-md-block">
                        <button type="button text text-left" class="btn text-white">REQUEST QUOTE</button>

                    </div>-->
                  </div>
                  <div class="carousel-item">
                      <img src="<?php echo base_url();?>pwit/img/banner.jpg" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                      <img src="<?php echo base_url();?>pwit/img/banner.jpg" class="d-block w-100" alt="...">
                  </div>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        </div>
    </div>
</section>


<section class="services pt-5">
    <div class="container">
        <div class="text-center"><h5>Build Quality</h5></div>
        <div class="text-center"><h5 class="font-weight-bold">Our Special Products/Services</h5></div>
        <p class="text-center">Indian App Developers is one of the veteran mobile app development companies in India.</p>
        <div class="row">
            <div class="col-sm-12 text-center">
                <p>
                    <button class="btn text-white" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">Services</button>
                    <button class="btn text-white" type="button" data-toggle="collapse" data-target="#multiCollapseExample2" aria-expanded="false" aria-controls="multiCollapseExample2">Products</button>
                </p>
                <div class="row pt-5">
                     <div class="col-sm-3">
                        <div class="card">
                          <div class="card-body">
                            <img src="<?php echo base_url();?>pwit/img/ser-1.png" class="w-25 " alt="...">
                            <h5 class="card-title pt-3">Software Development Services</h5>
                            <p class="card-text">Leading Service Provider of CRM Software Development Services, Customize Software Development Service, MLM Single Leg Software...</p>
                            <a href="#" class="text-dark">Read More</a>
                        </div>
                    </div>
                </div>
                    
                <div class="col-sm-3">
                    <div class="card">
                        <div class="card-body">
                            <img src="<?php echo base_url();?>pwit/img/ser-2.png" class="w-25 " alt="...">
                            <h5 class="card-title pt-3">Mobile App Development Services</h5>
                            <p class="card-text">Our range of services include Android Application Development Services, IOS Mobile App Development Services and Mobile... </p>
                            <a href="#" class="text-dark">Read More</a>
                        </div>
                    </div>
                </div>
                  
                <div class="col-sm-3">
                    <div class="card">
                          <div class="card-body">
                            <img src="<?php echo base_url();?>pwit/img/ser-3.png" class="w-25 " alt="...">
                            <h5 class="card-title pt-3">Game Development Services</h5>
                            <p class="card-text">Providing you the best range of Android Game Development Service, Cricket Fantasy Game Development Services, Roulette... </p>
                            <a href="#" class="text-dark">Read More</a>
                        </div>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="card">
                        <div class="card-body">
                            <img src="<?php echo base_url();?>pwit/img/ser-4.png" class="w-25 " alt="...">
                            <h5 class="card-title pt-3">Wesbite Design & Development</h5>
                            <p class="card-text">Our expertise in website development & designing, inquisitive and functional for your online business presence. Using the latest...</p>
                            <a href="#" class="text-dark">Read More</a>
                        </div>
                    </div>
                </div>

                </div>       
            </div>
        </div>
    </div>
  </div>
</section>


<section class="aboutus text-white pt-5">
    <div class="container pt-5">
        <div class="text-center"><h5>Planet Web IT Services</h5></div>
        <div class="text-center"><h5 class="font-weight-bold">About Our Company</h5></div>
        <div class="row">
            <div class="col-sm-12 text-center ">
                <p>Are there any leftovers in the kitchen? what are the expectations but technologically savvy. Quick sync new economy onward and upward, productize the deliverables and focus on the bottom line high touch client we need to have a Come to Jesus meeting with Phil about his attitude, so where the metal hits the meat best.</p>
        <button  type="button text" class="btn text-white">Read More</button>
            </div>
        </div>        
    </div>
</section>


<section class="features">
    <div class="container-fluid">
        <div class="text-center pt-5"><h6>Build Quality</h6></div>
        <div class="text-center"><h4 class="font-weight-bold">We’re Better. Here’s Why…</h4></div>
        <p class="text-center">Voice & Collaboration Services That Will Make You Fell Like You are in the Same Office.</p>
        <div class="row">
            <div class="col-sm-4">
                 <img src="<?php echo base_url();?>pwit/img/feat-banner.png">
            </div>
            <div class="col-sm-8">
                <div class="row">   

                    <div class="col-sm-4 ">                       
                        <!-- Card -->
                        <div class="card card-image" style="background-image: url(<?php echo base_url();?>pwit/img/feat-1.png); background-repeat: no-repeat;">
                            <!-- Content -->
                            <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
                                <div>                                    
                                    <h5 class="text-dark"><strong>Unified Communications</strong></h5>
                                    <p class="text-dark">Learn how to generate more leads on your website with hundreds of proven strategies</p>
                                </div>
                            </div>
                            <!-- Content -->
                        </div>
                        <!-- Card -->
                    </div>



                    <div class="col-sm-4">
                      <!-- Card -->
                        <div class="card card-image" style="background-image: url(<?php echo base_url();?>pwit/img/feat-2.png); background-repeat: no-repeat;">
                            <!-- Content -->
                            <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
                                <div>                                    
                                    <h5 class="text-dark"><strong>Clear, Reliable and Resilient</strong></h5>
                                    <p class="text-dark">Learn how to generate more leads on your website with hundreds of proven strategies</p>
                                </div>
                            </div>
                            <!-- Content -->
                        </div>
                        <!-- Card -->                      
                    </div>

                    <div class="col-sm-4 ">
                        <!-- Card -->
                        <div class="card card-image" style="background-image: url(<?php echo base_url();?>pwit/img/feat-3.png); background-repeat: no-repeat;">
                            <!-- Content -->
                            <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
                                <div>                                    
                                    <h5 class="text-dark"><strong>Clever Entreprise Collaboration</strong></h5>
                                    <p class="text-dark">The modern world is in a continuous movement and people everywhere.</p>
                                </div>
                            </div>
                            <!-- Content -->
                        </div>
                        <!-- Card -->
                    </div> 

                     <div class="col-sm-4 pt-3">
                        <!-- Card -->
                        <div class="card card-image" style="background-image: url(<?php echo base_url();?>pwit/img/feat-4.png); background-repeat: no-repeat;">
                            <!-- Content -->
                            <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
                                <div>                                    
                                    <h5 class="text-dark"><strong>Network Security Services</strong></h5>
                                    <p class="text-dark">Learn how to generate more leads on your website with hundreds of proven strategies</p>                                   
                                </div>
                            </div>
                            <!-- Content -->
                        </div>
                        <!-- Card -->
                    </div> 


                     <div class="col-sm-4  pt-3">
                        <!-- Card -->
                        <div class="card card-image" style="background-image: url(<?php echo base_url();?>pwit/img/feat-5.png); background-repeat: no-repeat;">
                            <!-- Content -->
                            <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
                                <div>                                    
                                    <h5 class="text-dark"><strong>Network & Call Quality Monitoring</strong></h5>
                                    <p class="text-dark">Learn how to generate more leads on your website with hundreds of proven strategies</p>                                   
                                </div>
                            </div>
                            <!-- Content -->
                        </div>
                        <!-- Card -->                    
                    </div>


                     <div class="col-sm-4  pt-3">
                        <!-- Card -->
                        <div class="card card-image" style="background-image: url(<?php echo base_url();?>pwit/img/feat-6.png); background-repeat: no-repeat;">
                            <!-- Content -->
                            <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
                                <div>                                    
                                    <h5 class="text-dark"><strong>Personalized Service & Support</strong></h5>
                                    <p class="text-dark">Learn how to generate more leads on your website with hundreds of proven strategies</p>                                   
                                </div>
                            </div>
                            <!-- Content -->
                        </div>
                        <!-- Card -->
                    </div> 

                </div>
            </div>
        </div>
    </div>
</section>


<section class="portfolio">
    <div class="container-fluid">
        <div class="text-center pt-5"><h6>Planet Web IT Service</h6></div>
        <div class="text-center"><h4 class="font-weight-bold">Our Portfolio</h5></div>
            <p class="text-center pb-5">We have some awesome previous projects.</p>
            <div class="row">

            <div class="col-sm-5 pl-0 pr-0">
              <div class="image"> <img src="<?php echo base_url();?>pwit/img/portfolio1.png" alt=""> <i class="fa fa-search fa-3x" class="img-fluid"></i> </div>
            </div>

            <div class="col-sm-2 pl-0 pr-0">
               <div class="image"> <img src="<?php echo base_url();?>pwit/img/portfolio3.png"alt=""> <i class="fa fa-search fa-3x" class="img-fluid"></i> </div>
            </div>

            <div class="col-sm-5 pl-0 pr-0">
               <div class="image"> <img src="<?php echo base_url();?>pwit/img/portfolio4.png"alt=""> <i class="fa fa-search fa-3x" class="img-fluid"></i> </div>
            </div>
             <div class="col-sm-2 pl-0 pr-0">
              <div class="image"> <img src="<?php echo base_url();?>pwit/img/portfolio01.png" alt=""> <i class="fa fa-search fa-3x" class="img-fluid"></i> </div>
            </div>

            <div class="col-sm-5 pl-0 pr-0">
               <div class="image"> <img src="<?php echo base_url();?>pwit/img/portfolio5.png" alt=""> <i class="fa fa-search fa-3x" class="img-fluid"></i> </div>
            </div>

            <div class="col-sm-5 pl-0 pr-0">
               <div class="image"> <img src="<?php echo base_url();?>pwit/img/portfolio6.png" alt=""> <i class="fa fa-search fa-3x" class="img-fluid"></i> </div>
            </div>

        </div>
    </div>
</section>


<section class="testimonial">
    <div class="container mt-5 ">
        <div class="text-center pt-5"><h6>Planet Web IT Services</h6></div>
        <div class="text-center"><h4 class="font-weight-bold">Our Client Testimonial</h4></div>
        <p class="text-center">We did awesome work with business ethics.</p>
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Carousel indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol> <!-- Wrapper for carousel items -->
            <div class="carousel-inner">
                <div class="item carousel-item active">
                    <div class="img-box"><img src="https://i.imgur.com/Ur43esv.jpg" alt=""></div>
                    <p class="testimonial">Phasellus vitae suscipit justo. Mauris pharetra feugiat ante id lacinia. Etiam faucibus mauris id tempor egestas. Duis luctus turpis at accumsan tincidunt. Phasellus risus risus, volutpat vel tellus ac, tincidunt fringilla massa. Etiam hendrerit dolor eget rutrum.</p>
                    <p class="overview"><b>Paula Wilsons</b>Seo Analyst </p>
                    <div class="star-rating"> </div>
                </div>
                <div class="item carousel-item">
                    <div class="img-box"><img src="https://i.imgur.com/8RKXAIV.jpg" alt=""></div>
                    <p class="testimonial">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu sem tempor, varius quam at, luctus dui. Mauris magna metus, dapibus nec turpis vel, semper malesuada ante. Vestibulum idac nisl bibendum scelerisque non non purus. Suspendisse varius nibh non aliquet.</p>
                    <p class="overview"><b>Paula Wilson</b>Media Analyst </p>
                    <div class="star-rating"> </div>
                </div>
                <div class="item carousel-item">
                    <div class="img-box"><img src="https://i.imgur.com/J6l19aF.jpg" alt=""></div>
                    <p class="testimonial">Vestibulum quis quam ut magna consequat faucibus. Pellentesque eget nisi a mi suscipit tincidunt. Utmtc tempus dictum risus. Pellentesque viverra sagittis quam at mattis. Suspendisse potenti. Aliquam sit amet gravida nibh, facilisis gravida odio. Phasellus auctor velit.</p>
                    <p class="overview"><b>Antonio Moreno</b>Web Developer</p>
                    <div class="star-rating"> </div>
                </div>
            </div> <!-- Carousel controls --> <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev"> <i class="fas fa-chevron-left"v class="text-white"></i></a> <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next"> <i class="fa fa-angle-right"></i> </a>
        </div>
    </div>
</section>


<section class="ourclient text-center text-dark">
    <div class="container">         
        <div class="row">
            <div id="testimonialbox" class="carousel slide" data-ride="carousel">
                <div class="row">
                    <div class="col-sm-1">
                        <a class="carousel-control-prev" href="#testimonialbox" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                    </div> 
                    <div class="col-sm-10">
                        <ol class="carousel-indicators">
                            <li data-target="#testimonialbox" data-slide-to="0" class="active"></li>
                            <li data-target="#testimonialbox" data-slide-to="1"></li>
                            <li data-target="#testimonialbox" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item text-center">
                                <div class="row my-5">
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client1.png" class="mr-3" alt="...">
                                    </div>                         
                                    <div class="col-sm-2">                                                                            
                                        <img src="<?php echo base_url();?>pwit/img/client2.png" class="mr-3" alt="...">
                                    </div>
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client3.png" class="mr-3" alt="...">
                                    </div>                          
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client4.png" class="mr-3" alt="...">
                                    </div>
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client5.png" class="mr-3" alt="...">
                                    </div>
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client6.png" class="mr-3" alt="...">
                                    </div>                        
                                </div>
                            </div> 
                            <div class="carousel-item active text-center">
                                <div class="row my-5">
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client2.png" class="mr-3" alt="...">
                                    </div>                 
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client1.png" class="mr-3" alt="...">
                                    </div>
                                    <div class="col-sm-2">                                                                     
                                        <img src="<?php echo base_url();?>pwit/img/client6.png" class="mr-3" alt="...">
                                    </div>                          
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client5.png" class="mr-3" alt="...">
                                    </div> 
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client4.png" class="mr-3" alt="...">
                                    </div> 
                                    <div class="col-sm-2">
                                        <img src="<?php echo base_url();?>pwit/img/client3.png" class="mr-3" alt="...">
                                    </div>           
                                </div>
                            </div> 
                        </div>
                    </div>
                    <div class="col-sm-1">
                        <a class="carousel-control-next" href="#testimonialbox" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div> 
                </div>           
            </div>      
        </div>        
    </div>    
</section>



<section class="footer bg-dark">
    <div class="container">
        <div class="row ">
            <div class="col-sm-12">
                <div class="row text-white">
                    <div class="col-sm-3">

                          <div class="card-body">
                            <img src="<?php echo base_url();?>pwit/img/footer-logo.png" class="" alt="...">                            
                            <p class="card-text">Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day.</p>
                        </div>
                    
                    </div>
                    <div class="col-sm-3 pt-5">
                        <ul>
                            <h5 class="font-weight-bold">Quick Link</h5>
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> About us</a></li>
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> Services</a></li>
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> Portfolio</a></li>
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> Our Client</a></li>
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> Privacy Policy</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3 pt-5">
                            <ul>                            
                            <h5 class="font-weight-bold">Services</h5>                           
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> Mobile App Development</a></li>
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> Software Development</a></li>
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> Game App Development</a></li>
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> Website Development</a></li>
                            <li class="pt-2"><a href="#"><img src="<?php echo base_url();?>pwit/img/arrow.png"> Digital Marketing</a></li>
                            </ul>
                    </div>
                    <div class="col-sm-3 pt-5">
                         <ul class="text-white">
                            <h5 class="font-weight-bold">Stay Cannect</h5>
                            <li class="pt-2"><a href="#"></i><img src="<?php echo base_url();?>pwit/img/call.png">+91-9582215139</a></li>
                            <li class="pt-2"><a href=""></i><img src="<?php echo base_url();?>pwit/img/call.png"> 01204156709</a></li>
                            <li class="pt-2"><a href=""><img src="<?php echo base_url();?>pwit/img/mail.png">info@planetwebit.com</a></li>
                            <li class="pt-2"><a href=""><img src="<?php echo base_url();?>pwit/img/website.png">www.planetwebit.com</a></li>
                            <li class="pt-2"><img src="<?php echo base_url();?>pwit/img/location.png">Devsha Business Park <br>D-215, B-02 Sector 63 Noida, UP 201309</li> 
                            <div class="pt-3">
                               <a href=""><i class="fab fa-facebook-square text-white"></i><img src="<?php echo base_url();?>pwit/img/instagram.png"></a> 
                               <a href=""><i class="fab fa-facebook-square text-white"></i><img src="<?php echo base_url();?>pwit/img/linkedin.png"></a>
                               <a href=""><i class="fab fa-facebook-square text-white"></i><img src="<?php echo base_url();?>pwit/img/facebook.png"></a>
                               <a href=""><i class="fab fa-facebook-square text-white"></i><img src="<?php echo base_url();?>pwit/img/youtube.png"></a> 
                               </div>              
                         </ul> 
                   </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="copywrite py-2">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-sm-12 text-center text-white">
                2021 @Planet Web IT Services All rights reserved.
            </div> 
        </div>
    </div>
</section>



</body>



