<!doctype html>
<!--[if IE 9]>
<html class="lt-ie10" lang="en"> <![endif]-->
<html class="no-js" lang="en-US">

<!-- Mirrored from themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 16 Sep 2021 07:52:08 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<!-- /Added by HTTrack -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" href="<?php echo base_url()?>/dashbord/planet.png" type="image/x-icon">
    <title>Planet Web It Services</title>
    <link rel='dns-prefetch' href='http://maps.googleapis.com/' />
    <link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
    <link rel='dns-prefetch' href='http://s.w.org/' />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="alternate" type="application/rss+xml" title="Osterisk: VOIP &amp; Cloud Services WordPress Theme &raquo; Feed" href="feed/index.html" />
    <link rel="alternate" type="application/rss+xml" title="Osterisk: VOIP &amp; Cloud Services WordPress Theme &raquo; Comments Feed" href="comments/feed/index.html" />
    <script type="text/javascript">
        window._wpemojiSettings = {
            "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/",
            "ext": ".png",
            "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/",
            "svgExt": ".svg",
            "source": {
                "concatemoji": "http:\/\/themes.webdevia.com\/osterisk-voip-cloud-services-wordpress-theme\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.6"
            }
        };
        ! function(e, a, t) {
            var n, r, o, i = a.createElement("canvas"),
                p = i.getContext && i.getContext("2d");

            function s(e, t) {
                var a = String.fromCharCode;
                p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, e), 0, 0);
                e = i.toDataURL();
                return p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, t), 0, 0), e === i.toDataURL()
            }

            function c(e) {
                var t = a.createElement("script");
                t.src = e, t.defer = t.type = "text/javascript", a.getElementsByTagName("head")[0].appendChild(t)
            }
            for (o = Array("flag", "emoji"), t.supports = {
                    everything: !0,
                    everythingExceptFlag: !0
                }, r = 0; r < o.length; r++) t.supports[o[r]] = function(e) {
                if (!p || !p.fillText) return !1;
                switch (p.textBaseline = "top", p.font = "600 32px Arial", e) {
                    case "flag":
                        return s([127987, 65039, 8205, 9895, 65039], [127987, 65039, 8203, 9895, 65039]) ? !1 : !s([55356, 56826, 55356, 56819], [55356, 56826, 8203, 55356, 56819]) && !s([55356, 57332, 56128, 56423, 56128, 56418, 56128, 56421, 56128, 56430, 56128, 56423, 56128, 56447], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203, 56128, 56430, 8203, 56128, 56423, 8203, 56128, 56447]);
                    case "emoji":
                        return !s([55357, 56424, 8205, 55356, 57212], [55357, 56424, 8203, 55356, 57212])
                }
                return !1
            }(o[r]), t.supports.everything = t.supports.everything && t.supports[o[r]], "flag" !== o[r] && (t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && t.supports[o[r]]);
            t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && !t.supports.flag, t.DOMReady = !1, t.readyCallback = function() {
                t.DOMReady = !0
            }, t.supports.everything || (n = function() {
                t.readyCallback()
            }, a.addEventListener ? (a.addEventListener("DOMContentLoaded", n, !1), e.addEventListener("load", n, !1)) : (e.attachEvent("onload", n), a.attachEvent("onreadystatechange", function() {
                "complete" === a.readyState && t.readyCallback()
            })), (n = t.source || {}).concatemoji ? c(n.concatemoji) : n.wpemoji && n.twemoji && (c(n.twemoji), c(n.wpemoji)))
        }(window, document, window._wpemojiSettings);
    </script>
    <script>
        $('.previewimg').css("transition", "transform " + 0.02 * $('.previewimg').height() + "s ease");
    </script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
        
        .preview {
            position: relative;
            width: 100%;
            height: 300px;
            overflow: hidden;
            border: px solid red;
            background-color: transparent;
        }
        
        .preview .previewimg {
            width: 100%;
            height: auto;
            transform: translateY(0px);
            transition: 10s;
        }
        
        .preview:hover .previewimg {
            transform: translateY(calc(-100% + 300px));
        }
    </style>
    <link rel='stylesheet' id='wp-block-library-css' href='<?php echo base_url();?>web/wp-includes/css/dist/block-library/style.min5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='wc-block-vendors-style-css' href='<?php echo base_url();?>web/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style324d.css?ver=3.1.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wc-block-style-css' href='<?php echo base_url();?>web/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style324d.css?ver=3.1.0' type='text/css' media='all' />
    <link rel='stylesheet' id='contact-form-7-css' href='<?php echo base_url();?>web/wp-content/plugins/contact-form-7/includes/css/styles91d5.css?ver=5.4' type='text/css' media='all' />
    <link rel='stylesheet' id='rs-plugin-settings-css' href='<?php echo base_url();?>web/wp-content/plugins/revslider/public/assets/css/rs649c2.css?ver=6.2.22' type='text/css' media='all' />
    <style id='rs-plugin-settings-inline-css' type='text/css'>
        #rs-demo-id {}
    </style>
    <link rel='stylesheet' id='woocommerce-layout-css' href='<?php echo base_url();?>web/wp-content/plugins/woocommerce/assets/css/woocommerce-layout62d0.css?ver=4.5.3' type='text/css' media='all' />
    <link rel='stylesheet' id='woocommerce-smallscreen-css' href='<?php echo base_url();?>web/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen62d0.css?ver=4.5.3' type='text/css' media='only screen and (max-width: 768px)' />
    <link rel='stylesheet' id='woocommerce-general-css' href='<?php echo base_url();?>web/wp-content/plugins/woocommerce/assets/css/woocommerce62d0.css?ver=4.5.3' type='text/css' media='all' />
    <style id='woocommerce-inline-inline-css' type='text/css'>
        .woocommerce form .form-row .required {
            visibility: visible;
        }
    </style>
    <link rel='stylesheet' id='osterisk_body_google_fonts-css' href='http://fonts.googleapis.com/css?family=Martel+Sans%3A300%2C400%2C600%2C700%2C800%26subset%3Dlatin-ext&amp;ver=1.0.0' type='text/css' media='all' />
    <link rel='stylesheet' id='osterisk_header_google_fonts-css' href='http://fonts.googleapis.com/css?family=Martel+Sans%3A300%2C400%2C600%2C700%26subset%3Dlatin-ext&amp;ver=1.0.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wd_navigation_google_fonts-css' href='http://fonts.googleapis.com/css?family=Poppins%3A300%2C500%2C600%26subset%3Dlatin-ext&amp;ver=1.0.0' type='text/css' media='all' />
    <link rel='stylesheet' id='animation-custom-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/css/animate-custom5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='foundation-min-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/css/foundation.min5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='osterisk-app-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/css/app5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='component-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/css/vendor/component5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='osterisk-style-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/style5406.css?ver=5.5.6' type='text/css' media='all' />
    <style id='osterisk-style-inline-css' type='text/css'>
        .first-footer {
            background-color: rgba(255, 255, 255, 1);
        }
        
        .first-footer,
        .first-footer .block-title,
        .first-footer ul li a,
        .first-footer h6 {
            color: rgba(255, 255, 255, 1)
        }
        
        .second-footer {
            background: rgba(58, 70, 209, 1);
            ;
            color: rgba(255, 255, 255, 1);
        }
        
        .first-footer {
            background-image: url('<?php echo base_url();?>web/wp-content/uploads/2018/12/footer-bg.svg');
            background-size: cover;
        }
        
        .powered .block .menu li a,
        .footer-social-media li a {
            color: rgba(255, 255, 255, 1);
        }
        
        .powered .block .menu li {
            border-right-color: rgba(255, 255, 255, 1);
        }
        
        .titlebar {
            ;
            ;
            background-repeat: no-repeat;
        }
        
        .titlebar #page-title {
            text-align: left;
            ;
            ;
        }
        
        #page-title,
        .breadcrumbs a {
            ;
        }
        
        .header-top.social_top_bar,
        .orange_bar {
            background: rgba(24, 27, 42, 1);
            ;
        }
        
        .header-top.social_top_bar,
        .orange_bar,
        .l-header .header-top .contact-info,
        .l-header .header-top i,
        .l-header .header-top .social-icons.accent li i,
        #lang_sel_list a.lang_sel_sel,
        #lang_sel_list>ul>li a {
            color: rgba(255, 255, 255, 1);
            ;
        }
        
        body,
        body p {
            font-size: 15px;
            ;
            font-family: Martel Sans;
            ;
            font-style: normal;
            ;
            font-weight: 300;
            ;
        }
        
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .menu-list a {
            font-family: Martel Sans;
            font-style: normal;
            font-weight: 600;
        }
        
        .top-bar .top-bar-right .menu li a {
            font-size: 14px;
            font-family: Poppins;
            font-style: normal;
            font-weight: 500;
            text-transform: uppercase;
        }
        
        .primary-color_bg,
        .square-img>a::before,
        .boxes .box>a::before,
        .boxes .box .flipper a::before,
        .wd_onepost .title-block span,
        .one_post_box .box_image .titel_icon .box_icon,
        .one_post_box .more,
        .boxes .box-container>a::before,
        .boxes .box-container .flipper a::before,
        .layout-4 div.box-icon i.fa,
        .boxes.small.layout-5 .box-icon,
        .boxes.small.layout-5-inverse .box-icon,
        .boxes.small.layout-6 .box-icon i.fa,
        .carousel_blog span.tag a,
        .wd-carousel-container .carousel-icon i,
        .search_box input[type='submit'],
        table thead,
        table tfoot,
        .block-block-17,
        .row.call-action,
        .blog-info,
        button.dark:hover,
        button.dark:focus,
        .button.dark:hover,
        .button.dark:focus,
        span.wpb_button:hover,
        span.wpb_button:focus,
        .woocommerce .widget_price_filter .ui-slider .ui-slider-range,
        .woocommerce-page .widget_price_filter .ui-slider .ui-slider-range,
        .products .product .button,
        .woocommerce #content input.button.alt,
        .woocommerce #respond input#submit.alt,
        .woocommerce a.button.alt,
        .woocommerce button.button.alt,
        .woocommerce input.button.alt,
        .woocommerce-page #content input.button.alt,
        .woocommerce-page #respond input#submit.alt,
        .woocommerce-page a.button.alt,
        .woocommerce-page button.button.alt,
        .woocommerce-page input.button.alt,
        .woocommerce #content input.button:hover,
        .woocommerce #respond input#submit:hover,
        .woocommerce a.button:hover,
        .woocommerce button.button:hover,
        .woocommerce input.button:hover,
        .woocommerce-page #content input.button:hover,
        .woocommerce-page #respond input#submit:hover,
        .woocommerce-page a.button:hover,
        .woocommerce-page button.button:hover,
        .woocommerce-page input.button:hover,
        .woocommerce span.onsale,
        .woocommerce-page span.onsale,
        .woocommerce-page button.button,
        .widget_product_search #searchsubmit,
        .widget_product_search #searchsubmit:hover,
        .page-numbers.current,
        .post-password-form input[type='submit'],
        .page-links a:hover,
        .blog-post .sticky .blog-info,
        .team-member-slider .owl-dots .owl-dot.active span,
        .team-member-slider .owl-theme .owl-dots .owl-dot:hover span,
        .team-member-carousel .owl-dots .owl-dot.active span,
        .team-member-carousel .owl-theme .owl-dots .owl-dot:hover span,
        .wd-image-text.style-2 h4::after,
        .blog-posts .read-more a::after,
        .top-bar-section .request-quote a,
        .contact-form [type='submit'],
        .woocommerce-page input.button,
        .woocommerce-page a.button,
        .first-footer .textwidget form .form-group button {
            background: rgba(51, 92, 255, 1);
        }
        
        .text_icon_hover>div .vc_row:hover {
            background: rgba(51, 92, 255, 1) !important;
        }
        
        .text_icon_hover>div .vc_row:hover .box-title-1,
        .text_icon_hover>div .vc_row:hover .box-body {
            color: #fff;
        }
        
        .blog-post .sticky .blog-info,
        .primary-color_bg,
        h2.contact-us::after,
        .contact-us-info h2::after,
        .who-we-are h2::after,
        input.wpcf7-submit,
        .sidebar-second.sidebar.sidebar-left ul li:hover,
        .first-footer .newsletter-div .newslettersubmit,
        .first-footer h2::after,
        .square-img>a::before,
        .boxes .box>a::before,
        .boxes .box .flipper a::before,
        .pricing-table.featured .special-box,
        .pricing-table.featured .special-box::before,
        .pricing-table.featured .special-box::after,
        .pricing-table.featured .pricing-table-header,
        div.vc_tta-color-grey.vc_tta-style-classic .vc_tta-panel.vc_active .vc_tta-panel-heading,
        div.vc_tta-color-grey.vc_tta-style-classic .vc_tta-tab.vc_active>a,
        .contact-form [type='submit'],
        .format-quote .post-box .post-body-container,
        .format-link .post-box .post-body-container,
        .wd-image-text.style-2 h4::after,
        .wd_onepost .title-block span,
        .one_post_box .box_image .titel_icon .box_icon,
        .one_post_box .more,
        .boxes .box-container>a::before,
        .boxes .box-container .flipper a::before,
        .layout-4 div.box-icon i.fa,
        .boxes.small.layout-5 .box-icon,
        .boxes.small.layout-5-inverse .box-icon,
        .boxes.small.layout-6 .box-icon i.fa,
        table thead,
        table tfoot,
        .block-block-17,
        .row.call-action,
        .blog-info,
        .wd-button:hover,
        .wd-button:focus,
        span.wpb_button:hover,
        span.wpb_button:focus,
        .woocommerce ul.products li.product span.onsale,
        .woocommerce-page ul.products li.product span.onsale,
        .woocommerce ul.products li.product .button {
            background: rgba(51, 92, 255, 1);
        }
        
        .wd-post {
            border-top: 3px solid rgba(58, 70, 209, 1);
        }
        
        .sidebar #s:active,
        .custom-tour .vc_tta-tabs-container li.vc_active a,
        .boxes.layout-3 .box-icon,
        .top-bar-section ul li:hover,
        .corporate-layout .top-bar-section ul li:hover,
        .corporate-layout .top-bar-section ul li.current-menu-item,
        .primary-color_border,
        .wpb-js-composer .vc_tta-container div.vc_tta-color-grey.vc_tta-style-classic.custom-tour .vc_tta-tabs-container li.vc_active a,
        .wpb-js-composer .vc_tta-container div.vc_tta-color-grey.vc_tta-style-classic.custom-tour .vc_tta-panel-body .container .img-wrp,
        .wpb-js-composer .vc_tta-color-grey.vc_tta-style-classic.vertical-tab .vc_tta-tabs-container li.vc_active a,
        .wpb-js-composer .vc_tta-color-grey.vc_tta-style-classic.vertical-tab .vc_tta-panel-body .container .img-wrp,
        .wpb-js-composer .vc_tta-container div.vc_tta-color-grey.vc_tta-style-classic.vertical-accordion .vc_tta-panels-container .vc_tta-panel.vc_active .vc_tta-panel-title a,
        .wpb-js-composer .vc_tta-container div.vc_tta-color-grey.vc_tta-style-classic.vertical-accordion .vc_tta-panel-body .container .img-wrp,
        .wpb-js-composer .vc_tta-color-grey.vc_tta-style-classic.custom-accordion .vc_tta-panel.vc_active .vc_tta-panel-heading,
        .section-container.auto>section.active .title,
        .section-container.auto>.section.active .title,
        .section-container.vertical-tabs>section.active>.title,
        .section-container.vertical-tabs>.section.active>.title,
        .section-container.vertical-nav>section.active>.title,
        .section-container.vertical-nav>.section.active>.title,
        .section-container.horizontal-nav>section.active>.title,
        .section-container.horizontal-nav>.section.active>.title,
        .section-container.accordion>section.active>.title,
        .section-container.accordion>.section.active>.title {
            border-color: rgba(51, 92, 255, 1);
        }
        
        .blog-info .arrow {
            border-color: transparent rgba(51, 92, 255, 1);
        }
        
        .primary-color_color,
        a,
        a:focus,
        a.active,
        a:active,
        a:hover,
        section.corporate .menu-item a i,
        .box-container:hover .box-title,
        .woocommerce .woocommerce-breadcrumb,
        .woocommerce-page .woocommerce-breadcrumb,
        div.boxes.small.layout-3 .box-icon i,
        .corporate-layout .header-top .contact-info .fa,
        .l-header .header-top .social-icons.accent li:hover i,
        .corporate-layout .top-bar-section ul li:hover:not(.has-form)>a,
        .corporate-layout .top-bar-section ul li.active:not(.has-form)>a:not(.button),
        .creative-layout .top-bar-section li.active:not(.has-form) a:not(.button),
        .team-member-item h3,
        .layout-4-testimonials .testimonial-box .author-info .rating li.selected .fa,
        .custom-tour .vc_tta-tabs-container li.vc_active a i,
        .social_media li i,
        .primary-color_color,
        .who-we-are h4,
        a,
        a:focus,
        a.active,
        a:active,
        a:hover,
        .contact-info i,
        .sidebar .block-title::before,
        .first-footer .newsletter-div a.footer-readmor,
        .first-footer ul li a::before,
        .pricing-table.featured .pricing-table-header .sign-up .button,
        .woocommerce-message::before,
        .social_media li i,
        .team-member-item h3,
        .wpb-js-composer .vc_tta-container div.vc_tta-color-grey.vc_tta-style-classic.custom-tour .vc_tta-tabs-container li.vc_active a i,
        .wpb-js-composer .vc_tta-color-grey.vc_tta-style-classic.vertical-tab .vc_tta-tabs-container li.vc_active a i,
        .wpb-js-composer .vc_tta-container div.vc_tta-color-grey.vc_tta-style-classic.vertical-accordion .vc_tta-panels-container .vc_tta-panel.vc_active .vc_tta-panel-title a i,
        .wd-testimonail blockquote cite,
        .layout-4-testimonials .testimonial-box .author-info .rating li.selected .fa,
        .boxes.small .box-icon i,
        .box-container:hover .box-title,
        .wd-pagination .page-numbers:hover {
            color: rgba(51, 92, 255, 1);
        }
        
        .boxes.small.layout-3 .box-icon i,
        div.boxes.small.layout-3:hover .box-icon i {
            color: rgba(255, 255, 255, 1);
        }
        
        .blog-posts h2 a,
        .breadcrumbs>*,
        .breadcrumbs,
        .wd-post__pagination .page-numbers,
        .woocommerce-pagination .page-numbers .page-numbers,
        .search-post__pagination .page-numbers {
            color: rgba(58, 70, 209, 1)
        }
        
        .wd-post__pagination .page-numbers,
        .woocommerce-pagination .page-numbers .page-numbers,
        .search-post__pagination .page-numbers {
            border-bottom: 3px solid rgba(58, 70, 209, 1)
        }
        
        .button,
        .button:hover,
        .button:focus,
        .products .product:hover .button,
        .woocommerce-product-search>input[type='submit'],
        .tag-cloud-link,
        .woocommerce .widget_price_filter .ui-slider .ui-slider-handle {
            background-color: rgba(58, 70, 209, 1)
        }
        
        .top-bar .top-bar-right .menu li a {
            color: rgba(255, 255, 255, 1);
        }
        
        header.l-header .top-bar-container .site-title-bar {
            background-color: rgba(58, 70, 209, 1);
        }
        
        header.l-header .top-bar-container .site-title-bar .menu-icon::after {
            background: rgba(255, 255, 255, 1);
            box-shadow: 0 7px 0 rgba(255, 255, 255, 1), 0 14px 0 rgba(255, 255, 255, 1);
        }
        
        @media only screen and (min-width: 64em) {
            header.l-header .top-bar-container.sticky.fixed,
            header.l-header .top-bar-container.sticky.fixed .site-navigation.top-bar {
                background-color: rgba(58, 70, 209, 1);
            }
            header.l-header.creative-layout .top-bar-right .menu li a:hover {
                color: rgba(255, 255, 255, 1);
            }
            header.l-header.creative-layout .top-bar-container.sticky.fixed .top-bar-right .menu>li>a:hover {
                color: rgba(255, 255, 255, 1);
            }
        }
        
        .first-footer,
        .first-footer .block-title,
        .first-footer ul li a {
            color: rgba(255, 255, 255, 1)
        }
        
        .top-bar,
        .corporate-layout .contain-to-grid.sticky,
        header.l-header,
        .corporate-layout .contain-to-grid {
            ;
        }
        
        #spaces-main {
            background-color: rgba(255, 255, 255, 1)
        }
        
        .blog-info .arrow {
            border-left-color: rgba(51, 92, 255, 1);
        }
        
        .ui-accordion-header-active,
        .ui-tabs-active,
        .box-icon,
        .woocommerce-message {
            border-top-color: rgba(51, 92, 255, 1)
        }
        
        .top-header .__top-header-right p {
            color: rgba(255, 255, 255, 1);
        }
        
        .wd-heading .title_a {
            ;
            ;
            font-weight: 600;
            ;
            ;
            ;
            ;
            ;
            ;
        }
        
        .wd-heading .sub_title_a {
            ;
            ;
            font-weight: 300;
            ;
            ;
            color: rgba(51, 51, 51, 1);
            ;
            ;
            ;
            ;
        }
        
        .wd-heading .title_b {
            ;
            ;
            font-weight: 600;
            ;
            ;
            ;
            ;
            ;
            ;
        }
        
        .wd-heading .sub_title_b {
            ;
            ;
            font-weight: 300;
            ;
            font-size: 24px;
            ;
            color: rgba(140, 146, 172, 1);
            ;
            ;
            line-height: 1.66;
            ;
            ;
        }
        
        .wd-heading .title_c {
            ;
            ;
            font-weight: 600;
            ;
            ;
            color: rgba(46, 50, 91, 1);
            ;
            ;
            ;
            ;
        }
        
        .wd-heading .sub_title_c {
            ;
            ;
            font-weight: 300;
            ;
            font-size: 17px;
            ;
            color: rgba(140, 146, 172, 1);
            ;
            ;
            line-height: 28px;
            ;
            ;
        }
        
        .wd-heading .hr_a {
            border-bottom-style: solid;
            ;
            ;
            ;
        }
        
        .wd-heading .hr_b {
            border-bottom-style: solid;
            ;
            ;
            ;
        }
        
        .wd-heading .hr_c {
            border-bottom-style: solid;
            ;
            ;
            ;
        }
    </style>
    <link rel='stylesheet' id='slick-min-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/css/slick.min5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='slick-theme-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/css/slick-theme5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelementplayer-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/css/mediaelementplayer5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='fontawesome-min-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/css/fontawesome.min5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='custom-line-css' href='<?php echo base_url();?>web/wp-content/themes/osterisk/style5406.css?ver=5.5.6' type='text/css' media='all' />
    <link rel='stylesheet' id='js_composer_front-css' href='<?php echo base_url();?>web/wp-content/plugins/js_composer/assets/css/js_composer.mina086.css?ver=6.3.0' type='text/css' media='all' />
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/jquery/jquery4a5f.js?ver=1.12.4-wp' id='jquery-core-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/revslider/public/assets/js/rbtools.min49c2.js?ver=6.2.22' id='tp-tools-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/revslider/public/assets/js/rs6.min49c2.js?ver=6.2.22' id='revmin-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70' id='jquery-blockui-js'></script>
    <script type='text/javascript' id='wc-add-to-cart-js-extra'>
        /* <![CDATA[ */
        var wc_add_to_cart_params = {
            "ajax_url": "\/osterisk-voip-cloud-services-wordpress-theme\/wp-admin\/admin-ajax.php",
            "wc_ajax_url": "\/osterisk-voip-cloud-services-wordpress-theme\/?wc-ajax=%%endpoint%%",
            "i18n_view_cart": "View cart",
            "cart_url": "http:\/\/themes.webdevia.com\/osterisk-voip-cloud-services-wordpress-theme\/cart\/",
            "is_cart": "",
            "cart_redirect_after_add": "no"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min62d0.js?ver=4.5.3' id='wc-add-to-cart-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-carta086.js?ver=6.3.0' id='vc_woocommerce-add-to-cart-js-js'></script>
    <script type='text/javascript' src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDcmvSA1VvwVKgtNBzsswD3rzafLCrRcuk&amp;ver=4.4.2" id='googlemapskey-js'></script>
    <link rel="https://api.w.org/" href="wp-json/index.html" />
    <link rel="alternate" type="application/json" href="<?php echo base_url();?>web/wp-json/wp/v2/pages/1124.json" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo base_url();?>web/wp-includes/wlwmanifest.xml" />
    <meta name="generator" content="WordPress 5.5.6" />
    <meta name="generator" content="WooCommerce 4.5.3" />
    <link rel="canonical" href="index.html" />
    <link rel='shortlink' href='index.html' />
    <link rel="alternate" type="application/json+oembed" href="<?php echo base_url();?>web/wp-json/oembed/1.0/embed03d5.json?url=http%3A%2F%2Fthemes.webdevia.com%2Fosterisk-voip-cloud-services-wordpress-theme%2F" />
    <link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embed68a9?url=http%3A%2F%2Fthemes.webdevia.com%2Fosterisk-voip-cloud-services-wordpress-theme%2F&amp;format=xml" />
    <noscript>
    <style>
      .woocommerce-product-gallery {
        opacity: 1 !important;
      }
    </style>
  </noscript>
    <meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
    <meta name="generator" content="Powered by Slider Revolution 6.2.22 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
    <script type="text/javascript">
        function setREVStartSize(e) {
            //window.requestAnimationFrame(function() {              
            window.RSIW = window.RSIW === undefined ? window.innerWidth : window.RSIW;
            window.RSIH = window.RSIH === undefined ? window.innerHeight : window.RSIH;
            try {
                var pw = document.getElementById(e.c).parentNode.offsetWidth,
                    newh;
                pw = pw === 0 || isNaN(pw) ? window.RSIW : pw;
                e.tabw = e.tabw === undefined ? 0 : parseInt(e.tabw);
                e.thumbw = e.thumbw === undefined ? 0 : parseInt(e.thumbw);
                e.tabh = e.tabh === undefined ? 0 : parseInt(e.tabh);
                e.thumbh = e.thumbh === undefined ? 0 : parseInt(e.thumbh);
                e.tabhide = e.tabhide === undefined ? 0 : parseInt(e.tabhide);
                e.thumbhide = e.thumbhide === undefined ? 0 : parseInt(e.thumbhide);
                e.mh = e.mh === undefined || e.mh == "" || e.mh === "auto" ? 0 : parseInt(e.mh, 0);
                if (e.layout === "fullscreen" || e.l === "fullscreen")
                    newh = Math.max(e.mh, window.RSIH);
                else {
                    e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
                    for (var i in e.rl)
                        if (e.gw[i] === undefined || e.gw[i] === 0) e.gw[i] = e.gw[i - 1];
                    e.gh = e.el === undefined || e.el === "" || (Array.isArray(e.el) && e.el.length == 0) ? e.gh : e.el;
                    e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
                    for (var i in e.rl)
                        if (e.gh[i] === undefined || e.gh[i] === 0) e.gh[i] = e.gh[i - 1];

                    var nl = new Array(e.rl.length),
                        ix = 0,
                        sl;
                    e.tabw = e.tabhide >= pw ? 0 : e.tabw;
                    e.thumbw = e.thumbhide >= pw ? 0 : e.thumbw;
                    e.tabh = e.tabhide >= pw ? 0 : e.tabh;
                    e.thumbh = e.thumbhide >= pw ? 0 : e.thumbh;
                    for (var i in e.rl) nl[i] = e.rl[i] < window.RSIW ? 0 : e.rl[i];
                    sl = nl[0];
                    for (var i in nl)
                        if (sl > nl[i] && nl[i] > 0) {
                            sl = nl[i];
                            ix = i;
                        }
                    var m = pw > (e.gw[ix] + e.tabw + e.thumbw) ? 1 : (pw - (e.tabw + e.thumbw)) / (e.gw[ix]);
                    newh = (e.gh[ix] * m) + (e.tabh + e.thumbh);
                }
                if (window.rs_init_css === undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));
                document.getElementById(e.c).height = newh + "px";
                window.rs_init_css.innerHTML += "#" + e.c + "_wrapper { height: " + newh + "px }";
            } catch (e) {
                console.log("Failure at Presize of Slider:" + e)
            }
            //});
        };
    </script>
    <style type="text/css" data-type="vc_custom-css">
        .from-shadow .vc_column-inner {
            box-shadow: 0 10px 50px rgba(4, 75, 194, 0.1);
            border: 1px solid rgba(88, 136, 247, 0.1);
        }
        
        .homepage-box-after-slider {
            z-index: 1;
        }
        
        input[type="submit"],
        .wpcf7 .wpcf7-form .contact_style_4 input[type="submit"] {
            font-size: 14px;
            padding: 16px 43px 11.5px;
        }
        
        .your-business-goes {
            background-repeat: no-repeat;
        }
        
        .wd-post__title {
            margin: 20px 0 7px;
        }
        
        .wd-post--multicolumn .wd-post__content {
            padding: 10px 25px 25px;
        }
        
        .vc_custom_1543849520960 .text-icon__icon-box {
            padding: 5px 25px 0 15px;
        }
        
        .our-numbers .wd-count-up::before {
            content: "";
            display: block;
            position: absolute;
            top: 50%;
            background: #ff337f;
            height: 2px;
            width: 25px;
            left: -20px;
        }
        
        .our-numbers .wpb_column .wpb_column:first-child .wd-count-up::before {
            display: none;
        }
        
        .unlimited-calling .text-icon__container {
            max-width: 600px;
        }
        
        .unlimited-calling .text-icon__icon-box {
            flex: 0 0 140px;
            padding: 5px 25px 0 35px;
        }
    </style>
    <link rel="stylesheet" media="all" href="<?php echo base_url();?>web/wp-includes/component/styles/setup.css">
    <link rel="stylesheet" media="all" href="<?php echo base_url();?>web/wp-includes/component/styles/says.css">
    <link rel="stylesheet" media="all" href="<?php echo base_url();?>web/wp-includes/component/styles/reply.css">
    <link rel="stylesheet" media="all" href="<?php echo base_url();?>web/wp-includes/component/styles/typing.css">
    <link rel="stylesheet" media="all" href="<?php echo base_url();?>web/wp-includes/component/styles/input.css">

    <style type="text/css" data-type="vc_shortcodes-custom-css">
        .vc_custom_1540816554017 {
            background-image: url(<?php echo base_url(); ?>web/wp-content/uploads/2018/09/why-bgf614.png?id=1186) !important;
            background-position: 0 0 !important;
            background-repeat: no-repeat !important;
        }
        
        .vc_custom_1540816602395 {
            background-image: url(http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/uploads/2018/09/section-bg-1.png?id=1160) !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: cover !important;
        }
        
        .vc_custom_1546107483164 {
            background-image: url(http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/uploads/2018/12/bg-1.png?id=2956) !important;
        }
        
        .vc_custom_1546949492607 {
            background: #f5f7ff url(http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/uploads/2018/10/princing-section-bg.png?id=2166) !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: cover !important;
        }
        
        .vc_custom_1540816724904 {
            background-image: url(http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/uploads/2018/09/bg-section-2.png?id=1304) !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: cover !important;
        }
        
        .vc_custom_1540816792866 {
            background-image: url(http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/uploads/2018/09/need-quote-bg.png?id=1213) !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: cover !important;
        }
        
        .vc_custom_1544029057798 {
            padding-top: 57px !important;
            padding-right: 46px !important;
            padding-bottom: 74px !important;
            padding-left: 55px !important;
            background-color: #ffffff !important;
            border-radius: 30px !important;
        }
        
        .vc_custom_1545230076800 {
            padding-top: 57px !important;
            padding-right: 46px !important;
            padding-bottom: 74px !important;
            padding-left: 55px !important;
            background-color: #ffffff !important;
            border-radius: 30px !important;
        }
        
        .vc_custom_1544029168757 {
            padding-top: 57px !important;
            padding-right: 46px !important;
            padding-bottom: 74px !important;
            padding-left: 55px !important;
            background-color: #ffffff !important;
            border-radius: 30px !important;
        }
        
        .vc_custom_1547853243628 {
            background-position: 0 0 !important;
            background-repeat: no-repeat !important;
        }
        
        .vc_custom_1547853252768 {
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: contain !important;
        }
        
        .vc_custom_1536411014924 {
            background-image: url(http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/uploads/2018/07/Tracé-1176.png?id=774) !important;
        }
        
        .vc_custom_1543883114959 {
            padding-top: 50px !important;
            padding-right: 50px !important;
            padding-bottom: 50px !important;
            padding-left: 25px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1543883152426 {
            padding-top: 50px !important;
            padding-right: 50px !important;
            padding-bottom: 50px !important;
            padding-left: 25px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1543883657105 {
            padding-top: 50px !important;
            padding-right: 50px !important;
            padding-bottom: 50px !important;
            padding-left: 25px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1543883632964 {
            padding-top: 50px !important;
            padding-right: 50px !important;
            padding-bottom: 50px !important;
            padding-left: 25px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1543884199059 {
            padding-top: 50px !important;
            padding-right: 50px !important;
            padding-bottom: 50px !important;
            padding-left: 25px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1543884221182 {
            padding-top: 50px !important;
            padding-right: 50px !important;
            padding-bottom: 50px !important;
            padding-left: 25px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1547038167358 {
            padding-top: 55px !important;
            padding-right: 50px !important;
            padding-bottom: 25px !important;
            padding-left: 50px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1546542041087 {
            padding-top: 26px !important;
            padding-right: 62px !important;
            padding-bottom: 21px !important;
            padding-left: 25px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1546542265308 {
            padding-top: 26px !important;
            padding-right: 62px !important;
            padding-bottom: 21px !important;
            padding-left: 25px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1546542371201 {
            padding-top: 26px !important;
            padding-right: 62px !important;
            padding-bottom: 21px !important;
            padding-left: 25px !important;
            background-color: #ffffff !important;
        }
        
        .vc_custom_1532687885046 {
            padding-top: 0px !important;
        }
        
        .vc_custom_1546961743360 {
            background-color: #ffffff !important;
            border: 1px solid #000000 !important;
        }
        
        .vc_custom_1546947967918 {
            background-color: #3a46d1 !important;
        }
        
        .vc_custom_1547042509658 {
            background-color: #ff337f !important;
        }
        
        .vc_custom_1546947986211 {
            background-color: #3a46d1 !important;
        }
        
        .vc_custom_1547150862765 {
            background-image: url(http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/uploads/2018/07/Tracé-1164.png?id=758) !important;
            background-position: 0 0 !important;
            background-repeat: no-repeat !important;
        }
        
        .vc_custom_1547150562165 {
            margin-left: -25px !important;
            padding-top: 0px !important;
            padding-right: 0px !important;
            padding-bottom: 0px !important;
            padding-left: 0px !important;
        }
        
        .vc_custom_1547150578518 {
            margin-left: -25px !important;
            padding-top: 10px !important;
            padding-right: 0px !important;
            padding-bottom: 10px !important;
            padding-left: 0px !important;
        }
        
        .vc_custom_1547225205572 {
            padding-top: 300px !important;
            padding-bottom: 300px !important;
        }
        
        .vc_custom_1539423517107 {
            padding-top: 0px !important;
        }
        
        .vc_custom_1539423532483 {
            padding-top: 0px !important;
        }
        
        .vc_custom_1532693857197 {
            padding-top: 0px !important;
        }
        
        .flip-card {
            display: inline-block;
            background-color: transparent;
            width: 150px;
            height: 150px;
            margin: 10px;
            perspective: 1000px;
        }
        
        .flip-card-inner {
            position: relative;
            width: 90%;
            height: 100%;
            text-align: center;
            transition: transform 0.6s;
            transform-style: preserve-3d;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        }
        
        .flip-card:hover .flip-card-inner {
            transform: rotateY(180deg);
        }
        
        .flip-card-front,
        .flip-card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
        }
        
        .flip-card-front {
            background-color: #bbb;
            color: black;
        }
        
        .flip-card-back {
            background-color: #2980b9;
            color: white;
            transform: rotateY(180deg);
        }
        /*chatbot*/
        
        .chat_icon {
            position: fixed;
            right: 30px;
            bottom: 0px;
            font-size: 80px;
            color: rgb(92, 91);
            cursor: pointer;
            z-index: 1000;
        }
        
        .bubble-container {
            height: 100vh;
        }
        
        .bubble-container .input-wrap textarea {
            margin: 0;
            width: calc(100% - 40px);
        }
        
        .customChat {
            width: 25%;
            height: 70%;
            position: fixed;
            right: 20px;
            background-color: tomato;
            bottom: 40px;
            padding: 10px;
            box-shadow: 0px 0px 10px red;
            border-radius: 10px;
        }
        
        .open-button {
            background-color: #555;
            color: white;
            padding: 16px 20px;
            border: none;
            cursor: pointer;
            opacity: 0.8;
            position: fixed;
            bottom: 23px;
            right: 28px;
            width: 280px;
            z-index: 1001;
        }
    </style>

    </style><noscript>
    <style>
      .wpb_animate_when_almost_visible {
        opacity: 1;
      }
    </style>
  </noscript>

</head>

<body class="home page-template-default page page-id-1124 theme-osterisk woocommerce-no-js wd_page_transitions wpb-js-composer js-comp-ver-6.3.0 vc_responsive">


    <!...Chatbot..>
    <div class="chat_icon">
        <i class="fas fa-comments" aria-hidden="true"></i>
    </div>
    <div class="chat_box"></div>
    <!...Chatbot End..>
    <div id="spaces-main" class="pt-perspective ">
        <header class="l-header creative-layout" data-sticky-container>
            <div class="top-bar-container  sticky slideUp ">
                <div class="site-title-bar" data-responsive-toggle="mobile-menu" data-hide-for="large">
                    <div class="title-bar-left">
                        <button aria-label="Main Menu" class="menu-icon" type="button" data-toggle="mobile-menu"></button>
                        <span class="site-mobile-title title-bar-title logo">
                  <a href="" rel="home" title="Osterisk: VOIP &amp; Cloud Services WordPress Theme"
                    class="active"><img src="<?php echo base_url();?>web/wp-content/uploads/2018/09/logo.png" alt="logo" /></a>
                </span>
                    </div>
                </div>
                <nav class="site-navigation top-bar" role="navigation">
                    <div class="top-bar-left">
                        <div class="site-desktop-title top-bar-title">
                            <div class="logo-wrapper " data-dropdown-menu>
                                <div class="menu-text">
                                    <a href="<?php echo base_url();?>" rel="home" title="Osterisk: VOIP &amp; Cloud Services WordPress Theme" class="active"><img src="<?php echo base_url();?>web/wp-content/uploads/2018/09/logo.png" alt="logo" /></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="top-bar-right">
                        <ul id="menu-primary-menu" class="desktop-menu menu">
                            <li class="  menu-item menu-item-type-post_type menu-item-object-page    color-8 ">
                                <a href="<?php echo base_url();?>">Home</a>

                            </li>
                            <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children   is-dropdown-submenu-parent opens-right not-click has-dropdown not-click  color-3 menu-item-has-children">
                                <li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children   is-dropdown-submenu-parent opens-right not-click has-dropdown not-click mega-menu color-7 menu-item-has-children">
                                    <a href="#">Services</a>
                                    <ul class="submenu is-dropdown-submenu ">
                                        <li class=" mega-menu-column">
                                            <ul>
                                                <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="https://www.indiamart.com/planet-webit-services/software-development-services.html">Software
                              Development Services</a>
                                                    <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="https://www.indiamart.com/planet-webit-services/software-development-services.html#crm-software-development-services">CRM
                              Software</a>
                                                        <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="https://www.indiamart.com/planet-webit-services/software-development-services.html#customize-software-development-service">Customize
                              software</a>
                                                            <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="https://www.indiamart.com/planet-webit-services/software-development-services.html#mlm-single-leg-software-development-services">MLM
                              Software</a>
                                                                <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 ">
                                            </ul>
                                            </li>
                                            <li class=" mega-menu-column">
                                                <ul>
                                                    <li><a href="https://www.indiamart.com/planet-webit-services/website-development-services.html">Website
                              Development &#038; Input</a>
                                                        <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="https://www.indiamart.com/planet-webit-services/website-development-services.html#corporate-website-designing-services">Corporatte
                              Website Designing</a>
                                                            <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="https://www.indiamart.com/planet-webit-services/website-development-services.html#website-development-services">Website
                              Development</a>
                                                                <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="https://www.indiamart.com/planet-webit-services/website-development-services.html#ecommerce-website-development-service">Ecommerce
                              Website</a>
                                                                    <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 ">
                                                </ul>
                                                </li>
                                                <li class=" mega-menu-column">
                                                    <ul>
                                                        <li><a href="https://www.indiamart.com/planet-webit-services/website-designing-service.html">Website
                              Designing </a>
                                                            <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="https://www.indiamart.com/planet-webit-services/website-designing-service.html#static-website-designing-services">Static
                              Services & Designing Services</a>

                                                    </ul>
                                                    </li>
                                                    <li class=" mega-menu-column">
                                                        <ul>
                                                            <li><a href="https://www.indiamart.com/planet-webit-services/game-development-service.html">Game
                              Development Services</a>
                                                                <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="portfolio-gallery/index.html">Android Game Development</a>
                                                                    <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="portfolio-masonry-style/index.html">Cricket Fanasty </a>
                                                                        <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="portfolio-isotope/index.html">Roulette Game</a>
                                                                            <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="portfolio-isotope/index.html">Ludo Game</a>
                                                        </ul>
                                                        </li>
                                                        <li class=" mega-menu-column">
                                                            <ul>
                                                                <li><a href="portfolio-standard/index.html">UI Design Services</a>

                                                            </ul>
                                                            </li>
                                                            <li class=" mega-menu-column">
                                                                <ul>
                                                                    <li><a href="portfolio-standard/index.html">Mobile App Development Services</a>
                                                                        <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="portfolio-gallery/index.html">Android Application Development</a>
                                                                            <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-7 "><a href="portfolio-masonry-style/index.html">IOS Mobile App </a>

                                                                </ul>
                                                                </li>
                                    </ul>
                                    </li>
                                    
                                    </li>

                                    <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-8 ">
                                        <a href="#portfolio">Portfolio</a>
                                    </li>

                                    <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-8 ">
                                        <a href="#about">About</a>
                                    </li>
                                    <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-8 "><a href="<?php echo base_url();?>Home/contact_us">Contact us</a>
                        </ul>
                        <div class="header-cta show-for-large-up large-screen">
                            <a href="<?php echo base_url(); ?>Home/contact_us" class="wd-btn
            btn-solid btn-color-2 hover-color-1 btn-small btn-round  icon-after">
                    Request Quote </a>
                        </div>
                        <nav class="mobile-menu vertical menu" id="mobile-menu" role="navigation" data-animate="hinge-in-from-top hinge-out-from-top">
                            <ul id="menu-primary-menu-1" class="vertical menu" data-accordion-menu data-submenu-toggle="true">
                                <li id="menu-item-3150" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-1124 current_page_item current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-3150">
                                    <a href="<?php echo base_url();?>" aria-current="page">Home</a>
                                    <ul class="vertical nested menu">
                                        <li id="menu-item-3151" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-1124 current_page_item menu-item-3151">
                                            <a href="<?php echo base_url();?>" aria-current="page">Home – Cloud Communication</a>
                                        </li>
                                        <li id="menu-item-3152" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3152"><a href="home-cloud-hosting/index.html">Home – Cloud Hosting</a></li>
                                        <li id="menu-item-3155" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3155"><a href="home-tech-company/index.html">Home – Tech Company</a></li>
                                        <li id="menu-item-3156" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3156"><a href="home-business/index.html">Home &#8211; Business</a></li>
                                        <li id="menu-item-3154" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3154"><a href="home-saas-app-landing/index.html">Home – SAAS App Landing</a></li>
                                        <li id="menu-item-3153" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3153"><a href="home-digital-agency/index.html">Home – Digital Agency</a></li>
                                    </ul>
                                </li>
                                <li id="menu-item-1275" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-   children menu-item-1275">
                                    <a href="#">Pages</a>
                                    <ul class="vertical nested menu">
                                        <li id="menu-item-970" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-970"><a href="about-us-2/index.html">About Us</a></li>
                                        <li id="menu-item-359" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-359"><a href="pricing/index.html">Pricing</a></li>
                                        <li id="menu-item-2830" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2830"><a href="team-2/index.html">Team</a></li>
                                        <li id="menu-item-1807" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1807"><a href="services/index.html">Services</a></li>
                                        <li id="menu-item-1964" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1964"><a href="about-2/index.html">About</a></li>
                                        <li id="menu-item-2809" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2809"><a href="word-wide-custsdfgdomers/index.html">Page 404</a></li>
                                    </ul>
                                </li>
                                
                                <li id="menu-item-2810" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2810">
                                    <a href="#">Shop</a>
                                    <ul class="vertical nested menu">
                                        <li id="menu-item-561" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-561"><a href="shop/index.html">Shop I</a></li>
                                        <li id="menu-item-1052" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1052"><a href="shop2/index.html">Shop II</a></li>
                                        <li id="menu-item-2835" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-2835"><a href="product/cx100-speakerphone/index.html">Single Product</a></li>
                                    </ul>
                                </li>
                                <li id="menu-item-2836" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2836">
                                    <a href="#">Blog</a>
                                    <ul class="vertical nested menu">
                                        <li id="menu-item-357" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-357"><a href="blog/index.html">Blog Classic</a></li>
                                        <li id="menu-item-2857" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2857"><a href="blog-grid/index.html">Blog grid</a></li>
                                        <li id="menu-item-2858" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-2858"><a href="2018/12/28/best-voip-cloud-services-wordpress-theme/index.html">Single Post</a></li>
                                    </ul>
                                </li>
                                <li id="menu-item-1276" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1276">
                                    <a href="#">Elements</a>
                                    <ul class="vertical nested menu">
                                        <li id="menu-item-1371" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1371"><a href="accordions/index.html">Accordions</a></li>
                                        <li id="menu-item-1370" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1370"><a href="tabs-3/index.html">Tabs</a></li>
                                        <li id="menu-item-1277" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1277"><a href="button/index.html">Button</a></li>
                                        <li id="menu-item-1368" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1368"><a href="headings/index.html">Headings</a></li>
                                        <li id="menu-item-1369" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1369"><a href="forms-input/index.html">Forms &#038; Input</a></li>
                                        <li id="menu-item-1372" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1372"><a href="text-with-icon/index.html">Text with Icon</a></li>
                                        <li id="menu-item-1391" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1391"><a href="count-up/index.html">Count up</a></li>
                                        <li id="menu-item-1392" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1392"><a href="team-2/index.html">Team</a></li>
                                        <li id="menu-item-1393" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1393"><a href="testimonail/index.html">Testimonail</a></li>
                                        <li id="menu-item-1421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1421"><a href="progress-bar/index.html">Progress Bar</a></li>
                                        <li id="menu-item-1424" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1424"><a href="clients/index.html">Clients</a></li>
                                        <li id="menu-item-1423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1423"><a href="blog-shortcode/index.html">blog styles</a></li>
                                        <li id="menu-item-2825" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2825"><a href="portfolio-standard/index.html">Portfolio Standard</a></li>
                                        <li id="menu-item-2309" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2309"><a href="portfolio-gallery/index.html">Portfolio Gallery</a></li>
                                        <li id="menu-item-2307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2307"><a href="portfolio-masonry-style/index.html">Portfolio Masonry</a></li>
                                        <li id="menu-item-2308" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2308"><a href="portfolio-isotope/index.html">Portfolio Isotope</a></li>
                                    </ul>
                                </li>
                                <li id="menu-item-1701" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1701">
                                    <a href="contact-us/index.html">Contact us</a>
                                </li>
                            </ul>
                            <div class="header-cta show-for-medium-down">
                                <a href="contact-us/index.html" class="wd-btn
            btn-solid btn-color-2 hover-color-1 btn-small btn-round  icon-after">
                      Request Quote </a>
                            </div>
                        </nav>
                    </div>
                </nav>
            </div>
        </header>


        <section class="titlebar ">
            <div class="row">
                <!-- <div>
                    <h2 id="page-title" class="title">Contact us</h2>
                </div> -->
                <div>
                    <ul class="breadcrumbs">
                        <li><a href="../index.html">Home</a></li>
                        <li><strong> Contact us</strong></li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- content  -->
        <main class="l-main row">
            <div class="main large-12 small-12 columns">
                <article>
                    <div class="body field clearfix ">
                        <div class="vc_row wpb_row vc_row-fluid vc_custom_1532777876079">
                            <div class="custom-heading wpb_column vc_column_container vc_col-sm-5">
                                <div class="vc_column-inner">
                                    <div class="wpb_wrapper">
                                        <div class="wd-heading text-left  " style="max-width: 100%">


                                            <h2 style="margin:0;" class="title_c">
                                                Get in touch </h2>

                                            <p style="font-weight:300;font-size:17px;" class="sub_title_c">
                                                Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverable. Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo non habent claritatem insitamconsequat duis autem facilisis at vero eros
                                            </p>

                                        </div>



                                        <div class="wd_empty_space" data-heightmobile="20" data-heighttablet="20" data-heightdesktop="20">

                                        </div>







                                        <div class="wd-btn-wrap text-left ">
                                            <a href="#contact-form" class="wd-btn btn-solid btn-color-2 hover-color-1 btn-medium btn-round icon-hs-1 icon-before">
                                                <span class="button-wrp">
                                                    <i class="fa fa-envelope-o before"></i>
                                                    <span>Say Hello</span>
                                                </span>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-7">
                                <div class="vc_column-inner">
                                    <div class="wpb_wrapper">
                                        <div class=" vc_custom_1539371702567 text-icon text-icon--icon-left_position boxes  clearfix">
                                            <div class="text-icon__container   ">
                                                <div class="text-icon__icon-box">
                                                    <img src="<?php echo base_url();?>web/wp-content/uploads/2018/09/mail-4709_4f312e0a-56b3-4dbe-be5f-3ffe7a1982df.png" alt='icon' />
                                                </div>
                                                <div class="text-icon__content-box">
                                                    <h4 class="text-icon__title">
                                                        EMAIL ADDRESS </h4>
                                                    <p class="text-icon__text"><a href="http://themes.webdevia.com/cdn-cgi/l/email-protection" class="__cf_email__">info@planetwebit.com</a></p>
                                                </div>
                                            </div>
                                        </div>


                                        <div class=" vc_custom_1539371709402 text-icon text-icon--icon-left_position boxes  clearfix">
                                            <div class="text-icon__container   ">
                                                <div class="text-icon__icon-box">
                                                    <img src="<?php echo base_url();?>web/wp-content/uploads/2018/09/message-app-4672_bb03b2ae-781b-4a63-aeff-c64156b65ef3.png" alt='icon' />
                                                </div>
                                                <div class="text-icon__content-box">
                                                    <h4 class="text-icon__title">
                                                        PHONE NUMBER </h4>
                                                    <p class="text-icon__text">01204156709, +91-9582215139 - Office</p>
                                                </div>
                                            </div>
                                        </div>


                                        <div class=" vc_custom_1539371714886 text-icon text-icon--icon-left_position boxes  clearfix">
                                            <div class="text-icon__container   ">
                                                <div class="text-icon__icon-box">
                                                    <img src="<?php echo base_url();?>web/wp-content/uploads/2018/09/map-marker.png" alt='icon' />
                                                </div>
                                                <div class="text-icon__content-box">
                                                    <h4 class="text-icon__title">
                                                        OUR ADDRESS </h4>
                                                    <p class="text-icon__text">D-215 Sector 63, Noida(201301)</p>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding">
                            <div class="wpb_column vc_column_container vc_col-sm-1">
                                <div class="vc_column-inner">
                                    <div class="wpb_wrapper"></div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-10">
                                <div class="vc_column-inner">
                                    <div class="wpb_wrapper">

                                        <div class="wd_empty_space" data-heightmobile="40" data-heighttablet="40" data-heightdesktop="112">

                                        </div>






                                        <script data-cfasync="false" src="<?php echo base_url();?>web/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
                                        <script>
                                            jQuery(function($) {

                                                var osterisk_map_style = 'wa_map_style4';
                                                switch (osterisk_map_style) {
                                                    case "wa_map_style1":
                                                        var styles = [{
                                                            "featureType": "administrative",
                                                            "elementType": "labels.text.fill",
                                                            "stylers": [{
                                                                "color": "#444444"
                                                            }]
                                                        }, {
                                                            "featureType": "landscape",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "color": "#f2f2f2"
                                                            }]
                                                        }, {
                                                            "featureType": "poi",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "road",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "saturation": -100
                                                            }, {
                                                                "lightness": 45
                                                            }]
                                                        }, {
                                                            "featureType": "road.highway",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "visibility": "simplified"
                                                            }]
                                                        }, {
                                                            "featureType": "road.arterial",
                                                            "elementType": "labels.icon",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "transit",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "water",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "color": "#24265c"
                                                            }, {
                                                                "visibility": "on"
                                                            }]
                                                        }];
                                                        break;
                                                    case "wa_map_style2":
                                                        var styles = [{
                                                            "featureType": "water",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#e9e9e9"
                                                            }, {
                                                                "lightness": 17
                                                            }]
                                                        }, {
                                                            "featureType": "landscape",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#f5f5f5"
                                                            }, {
                                                                "lightness": 20
                                                            }]
                                                        }, {
                                                            "featureType": "road.highway",
                                                            "elementType": "geometry.fill",
                                                            "stylers": [{
                                                                "color": "#ffffff"
                                                            }, {
                                                                "lightness": 17
                                                            }]
                                                        }, {
                                                            "featureType": "road.highway",
                                                            "elementType": "geometry.stroke",
                                                            "stylers": [{
                                                                "color": "#ffffff"
                                                            }, {
                                                                "lightness": 29
                                                            }, {
                                                                "weight": 0.2
                                                            }]
                                                        }, {
                                                            "featureType": "road.arterial",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#ffffff"
                                                            }, {
                                                                "lightness": 18
                                                            }]
                                                        }, {
                                                            "featureType": "road.local",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#ffffff"
                                                            }, {
                                                                "lightness": 16
                                                            }]
                                                        }, {
                                                            "featureType": "poi",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#f5f5f5"
                                                            }, {
                                                                "lightness": 21
                                                            }]
                                                        }, {
                                                            "featureType": "poi.park",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#dedede"
                                                            }, {
                                                                "lightness": 21
                                                            }]
                                                        }, {
                                                            "elementType": "labels.text.stroke",
                                                            "stylers": [{
                                                                "visibility": "on"
                                                            }, {
                                                                "color": "#ffffff"
                                                            }, {
                                                                "lightness": 16
                                                            }]
                                                        }, {
                                                            "elementType": "labels.text.fill",
                                                            "stylers": [{
                                                                "saturation": 36
                                                            }, {
                                                                "color": "#333333"
                                                            }, {
                                                                "lightness": 40
                                                            }]
                                                        }, {
                                                            "elementType": "labels.icon",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "transit",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#f2f2f2"
                                                            }, {
                                                                "lightness": 19
                                                            }]
                                                        }, {
                                                            "featureType": "administrative",
                                                            "elementType": "geometry.fill",
                                                            "stylers": [{
                                                                "color": "#fefefe"
                                                            }, {
                                                                "lightness": 20
                                                            }]
                                                        }, {
                                                            "featureType": "administrative",
                                                            "elementType": "geometry.stroke",
                                                            "stylers": [{
                                                                "color": "#fefefe"
                                                            }, {
                                                                "lightness": 17
                                                            }, {
                                                                "weight": 1.2
                                                            }]
                                                        }];
                                                        break;
                                                    case "wa_map_style3":
                                                        var styles = [{
                                                            "featureType": "water",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#193341"
                                                            }]
                                                        }, {
                                                            "featureType": "landscape",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#2c5a71"
                                                            }]
                                                        }, {
                                                            "featureType": "road",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#29768a"
                                                            }, {
                                                                "lightness": -37
                                                            }]
                                                        }, {
                                                            "featureType": "poi",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#406d80"
                                                            }]
                                                        }, {
                                                            "featureType": "transit",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#406d80"
                                                            }]
                                                        }, {
                                                            "elementType": "labels.text.stroke",
                                                            "stylers": [{
                                                                "visibility": "on"
                                                            }, {
                                                                "color": "#3e606f"
                                                            }, {
                                                                "weight": 2
                                                            }, {
                                                                "gamma": 0.84
                                                            }]
                                                        }, {
                                                            "elementType": "labels.text.fill",
                                                            "stylers": [{
                                                                "color": "#ffffff"
                                                            }]
                                                        }, {
                                                            "featureType": "administrative",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "weight": 0.6
                                                            }, {
                                                                "color": "#1a3541"
                                                            }]
                                                        }, {
                                                            "elementType": "labels.icon",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "poi.park",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#2c5a71"
                                                            }]
                                                        }];
                                                        break;
                                                    case "wa_map_style4":

                                                        var styles = [{
                                                            "featureType": "all",
                                                            "elementType": "labels.icon",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "administrative",
                                                            "elementType": "geometry.fill",
                                                            "stylers": [{
                                                                "color": "#eeeeee"
                                                            }]
                                                        }, {
                                                            "featureType": "administrative.country",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "lightness": "80"
                                                            }]
                                                        }, {
                                                            "featureType": "administrative.country",
                                                            "elementType": "labels",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "administrative.province",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "administrative.locality",
                                                            "elementType": "labels.text",
                                                            "stylers": [{
                                                                "visibility": "simplified"
                                                            }, {
                                                                "color": "#777777"
                                                            }]
                                                        }, {
                                                            "featureType": "administrative.locality",
                                                            "elementType": "labels.icon",
                                                            "stylers": [{
                                                                "visibility": "simplified"
                                                            }, {
                                                                "lightness": 60
                                                            }]
                                                        }, {
                                                            "featureType": "administrative.neighborhood",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "administrative.land_parcel",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "landscape.man_made",
                                                            "elementType": "geometry.fill",
                                                            "stylers": [{
                                                                "color": "#fbfbfb"
                                                            }]
                                                        }, {
                                                            "featureType": "landscape.man_made",
                                                            "elementType": "geometry.stroke",
                                                            "stylers": [{
                                                                "color": "#cfcfcf"
                                                            }]
                                                        }, {
                                                            "featureType": "landscape.man_made",
                                                            "elementType": "labels",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "landscape.natural",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#ffffff"
                                                            }]
                                                        }, {
                                                            "featureType": "landscape.natural",
                                                            "elementType": "labels",
                                                            "stylers": [{
                                                                "visibility": "simplified"
                                                            }]
                                                        }, {
                                                            "featureType": "poi",
                                                            "elementType": "geometry.fill",
                                                            "stylers": [{
                                                                "color": "#dedede"
                                                            }]
                                                        }, {
                                                            "featureType": "poi",
                                                            "elementType": "labels",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "poi",
                                                            "elementType": "labels.icon",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "poi.attraction",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#eeeeee"
                                                            }]
                                                        }, {
                                                            "featureType": "poi.business",
                                                            "elementType": "labels.icon",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "poi.park",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "color": "#d1d1d1"
                                                            }, {
                                                                "invert_lightness": true
                                                            }]
                                                        }, {
                                                            "featureType": "poi.park",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "invert_lightness": true
                                                            }]
                                                        }, {
                                                            "featureType": "poi.park",
                                                            "elementType": "labels",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "road.highway",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#e5e5e5"
                                                            }, {
                                                                "visibility": "simplified"
                                                            }]
                                                        }, {
                                                            "featureType": "road.highway",
                                                            "elementType": "labels",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "road.arterial",
                                                            "elementType": "geometry.stroke",
                                                            "stylers": [{
                                                                "color": "#cfcfcf"
                                                            }, {
                                                                "visibility": "on"
                                                            }, {
                                                                "weight": "0.55"
                                                            }]
                                                        }, {
                                                            "featureType": "road.arterial",
                                                            "elementType": "labels.text",
                                                            "stylers": [{
                                                                "visibility": "simplified"
                                                            }]
                                                        }, {
                                                            "featureType": "road.arterial",
                                                            "elementType": "labels.icon",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "road.local",
                                                            "elementType": "geometry.fill",
                                                            "stylers": [{
                                                                "color": "#efefef"
                                                            }]
                                                        }, {
                                                            "featureType": "road.local",
                                                            "elementType": "geometry.stroke",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "road.local",
                                                            "elementType": "labels",
                                                            "stylers": [{
                                                                "visibility": "simplified"
                                                            }]
                                                        }, {
                                                            "featureType": "road.local",
                                                            "elementType": "labels.text",
                                                            "stylers": [{
                                                                "color": "#777777"
                                                            }, {
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "road.local",
                                                            "elementType": "labels.icon",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "transit.line",
                                                            "elementType": "geometry",
                                                            "stylers": [{
                                                                "color": "#cdcdcd"
                                                            }]
                                                        }, {
                                                            "featureType": "transit.line",
                                                            "elementType": "labels",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }, {
                                                            "featureType": "transit.station",
                                                            "elementType": "geometry.fill",
                                                            "stylers": [{
                                                                "color": "#cccccc"
                                                            }]
                                                        }, {
                                                            "featureType": "water",
                                                            "elementType": "all",
                                                            "stylers": [{
                                                                "visibility": "simplified"
                                                            }]
                                                        }, {
                                                            "featureType": "water",
                                                            "elementType": "geometry.fill",
                                                            "stylers": [{
                                                                "color": "#e0e0e0"
                                                            }]
                                                        }, {
                                                            "featureType": "water",
                                                            "elementType": "labels",
                                                            "stylers": [{
                                                                "visibility": "off"
                                                            }]
                                                        }];

                                                }
                                                var styledMap = new google.maps.StyledMapType(styles, {
                                                    name: "Styled Map"
                                                });

                                                if ($('.map .map-canvas').length) {
                                                    $('.map .map-canvas').each(function(i, obj) {
                                                        osterisk_map_setting(this);
                                                    });
                                                }

                                                function osterisk_map_setting(el) {
                                                    if ($(el).length > 0) {
                                                        var locations = [
                                                            ['I am a Title change my', 'Company description', 28.628454, 77.376945],
                                                        ];

                                                        var map = new google.maps.Map(document.getElementById('map-canvas'), {
                                                            zoom: 14,
                                                            center: new google.maps.LatLng(28.628454, 77.376945),
                                                            mapTypeControlOptions: {
                                                                mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style']
                                                            }
                                                        })
                                                        map.mapTypes.set('map_style', styledMap);
                                                        map.setMapTypeId('map_style');

                                                        var infowindow = new google.maps.InfoWindow();

                                                        var marker, i, company_info

                                                        for (i = 0; i < locations.length; i++) {
                                                            marker = new google.maps.Marker({
                                                                position: new google.maps.LatLng(locations[i][2], locations[i][3]),
                                                                map: map,
                                                                icon: 'http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/themes/osterisk/images/unnamed.png'
                                                            });
                                                            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                                                return function() {
                                                                    company_info = '<div class="map-company-info">';
                                                                    company_info += '<h3> ' + locations[i][0] + '</h3>';
                                                                    company_info += '<p> ' + locations[i][1] + ' </p>';
                                                                    company_info += '</div>';
                                                                    infowindow.setContent(company_info);
                                                                    infowindow.open(map, marker);
                                                                }
                                                            })(marker, i));
                                                        }
                                                    };
                                                }
                                            });
                                        </script>
                                        <div class="map ">
                                            <div style="height: 338px;">
                                                 <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d9909.849669328989!2d77.31832801344056!3d28.579942203094248!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sa%2088%20sector%204%20noida!5e0!3m2!1sen!2sin!4v1631773446850!5m2!1sen!2sin" width="300" height="410" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                            </div>
                                        </div>




                                        <div class="wd_empty_space" data-heightmobile="40" data-heighttablet="40" data-heightdesktop="112">

                                        </div>






                                    </div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-1">
                                <div class="vc_column-inner">
                                    <div class="wpb_wrapper"></div>
                                </div>
                            </div>
                        </div>
                        <div class="vc_row-full-width vc_clearfix"></div>
                        <div id="contact-form" class="vc_row wpb_row vc_row-fluid vc_custom_1546284578974 vc_row-has-fill">
                            <div class="wpb_column vc_column_container vc_col-sm-12">
                                <div class="vc_column-inner vc_custom_1538216112567">
                                    <div class="wpb_wrapper">
                                        <div role="form" class="wpcf7" id="wpcf7-f1468-p85-o1" lang="en-US" dir="ltr">
                                            <div class="screen-reader-response">
                                                <p role="status" aria-live="polite" aria-atomic="true"></p>
                                                <ul></ul>
                                            </div>
                                            <form action="http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/contact-us/#wpcf7-f1468-p85-o1" method="post" class="wpcf7-form init" novalidate="novalidate" data-status="init">
                                                <div style="display: none;">
                                                    <input type="hidden" name="_wpcf7" value="1468" />
                                                    <input type="hidden" name="_wpcf7_version" value="5.4" />
                                                    <input type="hidden" name="_wpcf7_locale" value="en_US" />
                                                    <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f1468-p85-o1" />
                                                    <input type="hidden" name="_wpcf7_container_post" value="85" />
                                                    <input type="hidden" name="_wpcf7_posted_data_hash" value="" />
                                                </div>
                                                <div class="contact_style_3">
                                                    <div class="large-12 small-12 columns"><span class="wpcf7-form-control-wrap your-email"><input
                                                                type="email" name="your-email" value="" size="40"
                                                                class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-email"
                                                                aria-invalid="false" placeholder="Your Email" /></span>
                                                    </div>
                                                    <div class="large-6 small-12 columns"><span class="wpcf7-form-control-wrap your-name"><input type="text"
                                                                name="your-name" value="" size="40"
                                                                class="wpcf7-form-control wpcf7-text"
                                                                aria-invalid="false"
                                                                placeholder="Enter your name..." /></span></div>
                                                    <div class="large-6 small-12 columns"><span class="wpcf7-form-control-wrap your-phone"><input
                                                                type="text" name="your-phone" value="" size="40"
                                                                class="wpcf7-form-control wpcf7-text"
                                                                aria-invalid="false" placeholder="Phone" /></span></div>
                                                    <div class="large-12 small-12 columns"><span class="wpcf7-form-control-wrap your-message"><textarea
                                                                name="your-message" cols="40" rows="10"
                                                                class="wpcf7-form-control wpcf7-textarea"
                                                                aria-invalid="false"
                                                                placeholder="Here goes your message"></textarea></span><input type="submit" value="Click Here to Get Access Now" class="wpcf7-form-control wpcf7-submit" /></div>
                                                </div>
                                                <div class="wpcf7-response-output" aria-hidden="true"></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>



            </div>
        </main>
        <!-- /content  -->

        <section class="first-footer">
            <h3 class="hide">Footer</h3>
            <div class="monster">
                <div class="row">
                    <section class="block">
                        <div class="small-12 large-3 medium-12 columns">
                            <div id="text-3" class=" widget_text ">
                                <div class="textwidget">
                                    <p><img style="margin-bottom: 30px;" src="<?php echo base_url();?>web/wp-content/uploads/2018/11/Group-199.png" alt="Osterisk" /></p>
                                    <p>Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="small-12 large-3 medium-12 columns">
                            <div id="text-4" class=" widget_text ">
                                <h4 class="block-title">Business Hours</h4>
                                <div class="textwidget">
                                    <h6>Opining Days :</h6>
                                    <div>Monday – Friday : 10am to 6:30 pm</div>
                                    <div style="margin-bottom: 20px;">Saturday : 10am to 6:30 pm</div>
                                    <h6>Vacations :</h6>
                                    <div>All Sunday Days</div>
                                    <div>All Official Holidays</div>
                                </div>
                            </div>
                        </div>

                        <div class="small-12 large-3 medium-12 columns">
                            <div id="text-5" class=" widget_text ">
                                <h4 class="block-title">Practice Areas</h4>
                                <div class="textwidget">
                                    <div class="menu-left-menu-container">
                                        <ul id="menu-left-menu" class="menu">
                                            <li id="menu-item-2515" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2515">
                                                <a href="http://themes.webdevia.com/call-center/services/">Services</a>
                                            </li>
                                            <li id="menu-item-2516" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2516">
                                                <a href="http://themes.webdevia.com/consulting/strategic-planning/">Strategic
                                                    Planning</a>
                                            </li>
                                            <li id="menu-item-2517" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2517">
                                                <a href="http://themes.webdevia.com/consulting/audit-assurance/">Audit
                                                    &amp; Assurance</a>
                                            </li>
                                            <li id="menu-item-2518" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2518">
                                                <a href="http://themes.webdevia.com/consulting/business-services/">Business
                                                    Services</a>
                                            </li>
                                            <li id="menu-item-2519" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2519">
                                                <a href="http://themes.webdevia.com/consulting/sales-yrading/">Sales
                                                    &amp; Trading</a>
                                            </li>
                                            <li id="menu-item-2520" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2520">
                                                <a href="http://themes.webdevia.com/consulting/investment-banking/">Investment
                                                    Banking</a>
                                            </li>
                                            <li id="menu-item-2521" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2521">
                                                <a href="http://themes.webdevia.com/consulting/chemical-industry/">Chemical
                                                    Industry</a>
                                            </li>
                                            <li id="menu-item-2522" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2522">
                                                <a href="http://themes.webdevia.com/consulting/assembly-of-steel/">Investment
                                                    Management</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="small-12 large-3 medium-12 columns">
                            <div id="text-7" class=" widget_text ">
                                <h4 class="block-title">Instagram</h4>
                                <div class="textwidget">
                                    <p><img loading="lazy" width="531" height="173" class="alignleft wp-image-3011 size-full" src="<?php echo base_url();?>web/wp-content/uploads/2018/12/instagram.jpg" srcset="http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/uploads/2018/12/instagram.jpg 531w, http://themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/wp-content/uploads/2018/12/instagram-300x98.jpg 300w"
                                            sizes="(max-width: 531px) 100vw, 531px" /></p>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </section>

       <footer class="second-footer">
        <div class="row">
            <div class="copyright medium-3 large-3 columns">
                2021 PLANET WEB IT All rights reserved. </div>
            <div class="powered medium-6 large-6 columns">
                <section class="block">
                    <div class="menu-menu-container">
                        <ul id="menu-menu" class="menu">
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-9 "><a href="">Checkout</a></li>
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-10 "><a href="">Cart</a></li>
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-11 "><a href="">Shop</a></li>
                            <li class=" menu-item menu-item-type-post_type menu-item-object-page    color-12 "><a href="">Columns</a></li>
                        </ul>
                    </div>
                </section>
            </div>
            <div class="footer-social-media medium-3 large-3 columns">
                <ul class="footer-social-media">
                    <li class="">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                    </li>
                    <li class="">
                        <a href="#"><i class="fab fa-flickr"></i></a>
                    </li>
                    <li class="">
                        <a href="#"><i class="fab fa-google-plus-g"></i></a>
                    </li>
                    <li class="">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
    </div>

    <script type="text/html" id="wpb-modifications"></script>
    <link href="https://fonts.googleapis.com/css?family=Martel+Sans:600%2C900%2C800%2C300" rel="stylesheet" property="stylesheet" media="all" type="text/css">

    <script type="text/javascript">
        var c = document.body.className;
        c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
        document.body.className = c;
    </script>
    <script type="text/javascript">
        if (typeof revslider_showDoubleJqueryError === "undefined") {
            function revslider_showDoubleJqueryError(sliderID) {
                var err = "<div class='rs_error_message_box'>";
                err += "<div class='rs_error_message_oops'>Oops...</div>";
                err += "<div class='rs_error_message_content'>";
                err += "You have some jquery.js library include that comes after the Slider Revolution files js inclusion.<br>";
                err += "To fix this, you can:<br>&nbsp;&nbsp;&nbsp; 1. Set 'Module General Options' -> 'Advanced' -> 'jQuery & OutPut Filters' -> 'Put JS to Body' to on";
                err += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jQuery.js inclusion and remove it";
                err += "</div>";
                err += "</div>";
                var slider = document.getElementById(sliderID);
                slider.innerHTML = err;
                slider.style.display = "block";
            }
        }
    </script>
    <link rel='stylesheet' id='vc_animate-css-css' href='<?php echo base_url();?>web/wp-content/plugins/js_composer/assets/lib/bower/animate-css/animate.mina086.css?ver=6.3.0' type='text/css' media='all' />
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/dist/vendor/wp-polyfill.min89b1.js?ver=7.4.4' id='wp-polyfill-js'></script>
    <script type='text/javascript' id='wp-polyfill-js-after'>
        ('fetch' in window) || document.write('<script src="<?php echo base_url();?>web/wp-includes/js/dist/vendor/wp-polyfill-fetch.min6e0e.js?ver=3.0.0"></scr' + 'ipt>');
        (document.contains) || document.write('<script src="<?php echo base_url();?>web/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min2e00.js?ver=3.42.0"></scr' + 'ipt>');
        (window.DOMRect) || document.write('<script src="<?php echo base_url();?>web/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min2e00.js?ver=3.42.0"></scr' + 'ipt>');
        (window.URL && window.URL.prototype && window.URLSearchParams) || document.write('<script src="<?php echo base_url();?>web/wp-includes/js/dist/vendor/wp-polyfill-url.min5aed.js?ver=3.6.4"></scr' + 'ipt>');
        (window.FormData && window.FormData.prototype.keys) || document.write('<script src="<?php echo base_url();?>web/wp-includes/js/dist/vendor/wp-polyfill-formdata.mine9bd.js?ver=3.0.12"></scr' + 'ipt>');
        (Element.prototype.matches && Element.prototype.closest) || document.write('<script src="<?php echo base_url();?>web/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min4c56.js?ver=2.0.2"></scr' + 'ipt>');
    </script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/dist/i18n.min1a51.js?ver=4ab02c8fd541b8cfb8952fe260d21f16' id='wp-i18n-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/dist/vendor/lodash.mind1d1.js?ver=4.17.21' id='lodash-js'></script>
    <script type='text/javascript' id='lodash-js-after'>
        window.lodash = _.noConflict();
    </script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/dist/url.minbf85.js?ver=d80b474ffb72c3b6933165cc1b3419f6' id='wp-url-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/dist/hooks.min2e56.js?ver=63769290dead574c40a54748f22ada71' id='wp-hooks-js'></script>
    <script type='text/javascript' id='wp-api-fetch-js-translations'>
        (function(domain, translations) {
            var localeData = translations.locale_data[domain] || translations.locale_data.messages;
            localeData[""].domain = domain;
            wp.i18n.setLocaleData(localeData, domain);
        })("default", {
            "locale_data": {
                "messages": {
                    "": {}
                }
            }
        });
    </script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/dist/api-fetch.minf352.js?ver=0bb73d10eeea78a4d642cdd686ca7f59' id='wp-api-fetch-js'></script>
    <script type='text/javascript' id='wp-api-fetch-js-after'>
        wp.apiFetch.use(wp.apiFetch.createRootURLMiddleware("wp-json/index.html"));
        wp.apiFetch.nonceMiddleware = wp.apiFetch.createNonceMiddleware("9805524950");
        wp.apiFetch.use(wp.apiFetch.nonceMiddleware);
        wp.apiFetch.use(wp.apiFetch.mediaUploadMiddleware);
        wp.apiFetch.nonceEndpoint = "wp-admin/admin-ajaxf809.html?action=rest-nonce";
    </script>
    <script type='text/javascript' id='contact-form-7-js-extra'>
        /* <![CDATA[ */
        var wpcf7 = [];
        /* ]]> */
    </script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/contact-form-7/includes/js/index91d5.js?ver=5.4' id='contact-form-7-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min6b25.js?ver=2.1.4' id='js-cookie-js'></script>
    <script type='text/javascript' id='woocommerce-js-extra'>
        /* <![CDATA[ */
        var woocommerce_params = {
            "ajax_url": "\/osterisk-voip-cloud-services-wordpress-theme\/wp-admin\/admin-ajax.php",
            "wc_ajax_url": "\/osterisk-voip-cloud-services-wordpress-theme\/?wc-ajax=%%endpoint%%"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min62d0.js?ver=4.5.3' id='woocommerce-js'></script>
    <script type='text/javascript' id='wc-cart-fragments-js-extra'>
        /* <![CDATA[ */
        var wc_cart_fragments_params = {
            "ajax_url": "\/osterisk-voip-cloud-services-wordpress-theme\/wp-admin\/admin-ajax.php",
            "wc_ajax_url": "\/osterisk-voip-cloud-services-wordpress-theme\/?wc-ajax=%%endpoint%%",
            "cart_hash_key": "wc_cart_hash_23911338b4fa3b113623b40032d5cc6c",
            "fragment_name": "wc_fragments_23911338b4fa3b113623b40032d5cc6c",
            "request_timeout": "5000"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min62d0.js?ver=4.5.3' id='wc-cart-fragments-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/comment-reply.min5406.js?ver=5.5.6' id='comment-reply-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/hoverIntent.minc245.js?ver=1.8.1' id='hoverIntent-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/themes/osterisk/js/wd-script.min8a54.js?ver=1.0.0' id='<?php echo base_url();?>web/wd-script-min-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-includes/js/wp-embed.min5406.js?ver=5.5.6' id='wp-embed-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.mina086.js?ver=6.3.0' id='wpb_composer_front_js-js'></script>
    <script type='text/javascript' src='<?php echo base_url();?>web/wp-content/plugins/js_composer/assets/lib/vc_waypoints/vc-waypoints.mina086.js?ver=6.3.0' id='vc_waypoints-js'></script>
    <script>
        function getElemnet(ID) {
            return document.getElementById(ID);

        }

        function openCloseChatBot(ID) {
            var nextFlag = (getElemnet(ID).style.visibility == "visible") ? 'hidden' : 'visible';
            getElemnet(ID).style.visibility = nextFlag;

        }
    </script>



    <button class="open-button" onclick="openCloseChatBot('id_chatBotDiv')">Let's Talk</button>
    <i class="fas fa-comments"></i>




    <div style="background-color: white ; visibility: hidden;" id="id_chatBotDiv">
        <!-- container element for chat window -->
        <div class="chat_icon customChat" id="chat">

        </div>

        <!-- import the JavaScript file -->
        <script src="<?php echo base_url();?>web/wp-includes/component/Bubbles.js"></script>

        <script>
            // conversation object stored in separate variable:
            var convo = {
                    // "ice" (as in "breaking the ice") is a required conversation object
                    // that maps the first thing the bot will say to the user
                    ice: {
                        // "says" defines an array of sequential bubbles
                        // that the bot will produce
                        says: [
                            "Hello!",
                            "Let's explore advanced chat flows with <em>chat-bubble</em>.",

                            "To begin, choose how you'd like this (example) conversation to proceed...",
                            "...We can either talk about <strong>Web Design and Android App</strong> or <strong>other special things</strong>. Which one shall it be?",
                            "<img src=<?php echo base_url();?>web/osterisk-voip-cloud-services-wordpress-theme/wp-content/gif/angry-cat.gif  />"
                        ],
                        // "reply" is an array of possible options the user can pick from
                        // as a reply
                        reply: [{
                            question: "Web design and android app!", // label for the reply option
                            answer: "chapter-one" // key for the next conversation object
                        }, {
                            question: "No, thanks.", // label for the reply option
                            answer: "end" // key for an "escape valve"; we refer to this whenever a reply signals the end of the convo
                        }, {
                            question: "What “other special things?”", // label for the reply option
                            answer: "sidetrack" // key for a "side note" we can reference from multiple points in the chat
                        }]
                    }, // end required "ice" conversation object

                    // side note
                    sidetrack: {
                        says: [
                            "Things which go way beyond a single topic of conversation!",
                            "<img src=https://meanbusiness.com/wp-content/uploads/2018/04/Walk-Cycle-Banana-Jelly-Bean-GIF-by-Ethan-Barnowsky-source.gif />",
                            "As in this case we are branching out from the main topic of “bananas and android app” into another series of prompts and possible replies.",
                            "This could be a useful way provide more instructions or context."
                        ],
                        reply: [{
                            question: "Tell me more.",
                            answer: "intro-context" // key for another side note; in this instance, we're using it to contextualize the Q&A we're heading into
                        }, {
                            question: "Got it: on with the chat!",
                            answer: "chapter-one" // no further sidetrack required, returning to the main conversation tree
                        }]
                    },

                    // another side note
                    "intro-context": {
                        says: [
                            "This is an example of further instructions...",
                            "...Context and side-notes...",
                            "...With a way to return back to the main trunk of the conversation, like so:"
                        ],
                        reply: [{
                            question: "To the main topic, web design and android app!",
                            answer: "chapter-one"
                        }]
                    },

                    // main conversation trunk
                    "chapter-one": {
                        says: [
                            "Excellent!",
                            "(This is the main topic of our chat.)",
                            "Web design and android app.",
                            "Now, which do you prefer best?"
                        ],
                        reply: [{
                            question: "Web design!",
                            answer: "chapter-two" // here both replies send people onto the same next chapter
                        }, {
                            question: "android app!", // both replies send people onto the same next chapter
                            answer: "chapter-two"
                        }, {
                            question: "What’s this button?",
                            answer: "intro-context"
                        }]
                    },
                    "chapter-two": {
                        says: [
                            "Both <strong>web design</strong> and <strong>android app</strong> take you here.",
                            "<img src=https://meanbusiness.com/wp-content/uploads/2018/04/IceCream-MultipleCones.gif />",
                            "Your next answer will take you to another prompt...",
                            "...Or to the end of the chat, an “escape valve” we can use to end the chat if you want."
                        ],
                        reply: [{
                            question: "Give me another prompt.",
                            answer: "chapter-four"
                        }, {
                            question: "End the chat.",
                            answer: "end" // an example of using the Escape Valve for ineligible, Not Applicable participants
                        }]
                    },

                    // this chapter is skipped
                    "chapter-three": {
                        // we skip this in this example to show you can do that; use it if you want.
                        says: [
                            "Go ahead to the next chapter.",
                            "<img src=http://meanbusiness.com/wp-content/uploads/2018/03/Coral-Participate-Phone_and_Laptop.jpg />"
                        ],
                        reply: [{
                            question: "OK, I will.",
                            answer: "chapter-four"
                        }]
                    },

                    // continue with main conversation trunk
                    "chapter-four": {
                        says: [
                            "Hey, you're awesome!",
                            "<img src=http://meanbusiness.com/wp-content/uploads/2018/02/mel_b-Thank-You.gif />",
                            "More prompts?"
                        ],
                        reply: [{
                            question: "Nope.",
                            answer: "end"
                        }, {
                            question: "Yes, more prompts!",
                            answer: "chapter-five"
                        }]
                    },
                    "chapter-five": {
                        says: [
                            "Answering 'Yes' here will open a new window with a page from another site...", // call a function to an external resource / application outside of chat-bubble's purview
                            "...And confirm that you're awesome, again.",
                            "Answering 'Not interested' will end the chat." // call a function to an external resource / application outside of chat-bubble's purview
                        ],
                        reply: [{
                            question: "Not interested.",
                            answer: "end"
                        }, {
                            question: "Yes!",
                            answer: "externalResourceFunction" // function name that will be executed
                        }]
                    },
                    end: {
                        says: [
                            "Thanks for your time and attention.",
                            "<img src=https://media.giphy.com/media/xUOxeXsWhw6DCW1cSA/giphy.gif>",
                            "The chat is over, but you can <strong>start over</strong> to see how this conversation could have gone differently."
                        ],
                        reply: [{
                            question: "Start over 😁",
                            answer: "ice"
                        }]
                    }
                } // end conversation object

            // initialize by constructing a named function...
            var chatWindow = new Bubbles(
                document.getElementById("chat"), // ...passing HTML container element...
                "chatWindow" // ...and name of the function as a parameter
            )

            // `.talk()` will get your bot to begin the conversation
            chatWindow.talk(
                // pass your JSON/JavaScript object to `.talk()` function where
                // you define how the conversation between the bot and user will go
                convo
            )

            // this function is called when user clicks "Yes!" in the "chapter-four" dialogue
            externalResourceFunction = function() {
                // together with the function we'll restart the conversation starting from "capther-four"
                // to make sure the user isn't left hanging after the function below has been executed
                chatWindow.talk(convo, "chapter-four")

                // function that opens external window
                window.open(
                    "https://meanbusiness.com/wp-content/uploads/2018/04/IceCream-BananaSkis.gif",
                    "_blank",
                    "toolbar=no,scrollbars=no,menubar=no,resizable=no,location=no,titlebar=no,width=300,height=600"
                )
            }
        </script>
    </div>


</body>

<!-- Mirrored from themes.webdevia.com/osterisk-voip-cloud-services-wordpress-theme/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 16 Sep 2021 07:54:10 GMT -->

</html>